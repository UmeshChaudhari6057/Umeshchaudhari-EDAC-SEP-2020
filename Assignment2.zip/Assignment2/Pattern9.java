import java.util.*;

class Pattern9
{
  public static void main(String args[])
  {
	  int num;
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter value");
	  num=sc.nextInt();
	  int k=num;
	  for(int i=1; i<=num; i++)
	  {
		  for (int j=num; j>=i; j--)
		  {
			  System.out.print("*");
			  
		  }
		  System.out.println(" ");
	  }
	  
  }
}