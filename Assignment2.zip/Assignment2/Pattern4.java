import java.util.*;

class Pattern4
{
  public static void main(String args[])
  {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter value");
	  int num=sc.nextInt();
	  int y=num;
	  int odd=1;
        int sp=y-1;
        for (int i=1; i<=y;i++)
        {
            for (int j=1;j<=sp;j++)
            {
            System.out.print("  ");
            }
            int k=0;
            for (int j=1;j<=odd;j++)
            {
                if (j<=i)
                {
                k++;
                }
                else
                {
                k--;
                }
            System.out.print(k +" ");
            }
            odd=odd+2;
            System.out.println();
            sp--;
        }

	  
  }
}