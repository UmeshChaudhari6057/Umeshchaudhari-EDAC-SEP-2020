package Assingment1;

	public class Q19{  
		public static void main(String args[]){  
		System.out.println(Integer.toBinaryString(5));  
		  
		}}  


