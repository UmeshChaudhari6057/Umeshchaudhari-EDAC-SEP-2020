package Assingment1;

import java.util.Scanner;

public class Q5 {

	private static Scanner sc;

	public static void main(String[] args) {

        int num1, num2, mul;
         sc = new Scanner(System.in);
        System.out.println("Enter First Number: ");
        num1 = sc.nextInt();
        
        System.out.println("Enter Second Number: ");
        num2 = sc.nextInt();
        
        sc.close();
        mul = num1 * num2;
        System.out.println("Sum of these numbers: "+mul);

	}
}
