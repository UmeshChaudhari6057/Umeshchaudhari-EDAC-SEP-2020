package Assingment1;

public class Q21 {
	public static void main (String args[])
	{
	System.out.println(Integer.toOctalString(15));  
}
}